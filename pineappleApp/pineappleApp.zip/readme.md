# Pineapple Front End Code Challenge :pineapple:

See it Live here: https://onelineof.me/pineappleApp/

The app is made by utilising **CSS grid** for the names and buttons.

For getting the .JSON data needed to show to the user, the **javascript fetch API** is used.

The app gets the names and IDs of the first .JSON file, lists the names and makes a button for each name dynamically assigning to it the ID.

Then, when the user clicks a button to see more information, fetch is used again for the second .JSON, and with the help of the ID, it returns the right details to the user, inside of a lightbox.